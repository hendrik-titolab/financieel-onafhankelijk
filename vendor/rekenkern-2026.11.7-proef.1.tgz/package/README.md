# Rekenkern

De berekeningen achter de rekentools, los van elke website. Afgesplitst uit `financiele-planning` op 3 november 2026 (commit 9a0a15b). Geen schermen, geen PDF- of Excel-export, geen browsercode.

## Wat erin zit

| Onderdeel | Bestand |
|---|---|
| Fiscale cijfers, gegenereerd | `src/config/fiscaleParameters.ts` |
| Risicoprofielen, gegenereerd | `src/config/risicoprofielen.ts` |
| Bruto-netto en box 1 | `src/utils/brutoNetto.ts` |
| Box 3 | `src/utils/box3.ts` |
| Jaarruimte | `src/utils/jaarruimte.ts` |
| Rente op rente, maandelijks beleggen | `src/utils/renteOpRente.ts` |
| Inflatie | `src/utils/inflatie.ts` |
| Planner en Monte Carlo | `src/utils/pensionCalc.ts`, `src/utils/monteCarlo.ts` |

## Controleren

```bash
npm test
```

```bash
npx tsc --noEmit
```

`src/utils/__tests__/narekenen.onafhankelijk.test.ts` vergelijkt de kern met `narekenen/waarden.py`. Dat script deelt geen code met de kern. Draai het opnieuw als de cijfers wijzigen, want de cijfers staan er apart in:

```bash
python narekenen/waarden.py
```

## Bijwerken

1. Fiscale cijfers wijzigen in `Documents\Fiscale bron\fiscale-cijfers.json`. Draai daar `node genereer.mjs`; die schrijft de twee gegenereerde bestanden in deze map.
2. Bij elke wijziging die een uitkomst verandert: `MODEL_VERSIE` ophogen in `src/config/modelVersie.ts`, met uitleg, en `version` in `package.json` gelijk houden. CI controleert dit voor elk bestand in `src/utils` en `src/config`. Raakt een wijziging daar aantoonbaar geen uitkomst (alleen commentaar), zet dan in een commit de regel `Modelversie-ongewijzigd: <reden>`.
3. Via een pull request naar `main`. Daar draait de controle.
4. Op `main`, als de versie klaar is voor de sites: taggen.

```bash
git tag v2026.11.3
```

```bash
git push origin v2026.11.3
```

## Uitrol

Een tag `v*` start de workflow `Uitrol naar sites` (`.github/workflows/uitrol.yml`). Die draait de controle en zet daarna het pakket in een pull request bij elke site uit de lijst `matrix.site`. In die pull request draaien de controles van de site en maakt Vercel een testversie, voor zover de site die heeft.

**De workflow merget nooit.** Een merge naar `main` gaat direct live. Dat blijft een mensenbesluit, na het lezen van de pull request en het bekijken van de testversie.

Er komt geen pull request als:

- de controle faalt;
- de tag niet gelijk is aan `version` in `package.json`, of aan `MODEL_VERSIE`;
- de tag niet op `main` staat;
- de site al op deze of een nieuwere versie staat.

Het pakket is een binair bestand, dus de diff zegt niets. Daarom staan de commits en de gewijzigde bestanden in de tekst van de pull request. `financieel-onafhankelijk` is een openbare repo, dus die tekst is openbaar, net als de broncode in het pakket.

`scripts/wissel-pakket.mjs` past alleen de regels van rekenkern aan in `package.json` en `package-lock.json`, zodat er geen andere afhankelijkheden meeliften.

### Proef

Een tag `v2026.11.3-proef.1` test de route zonder risico. Hij hoeft niet op `main` te staan, `MODEL_VERSIE` blijft ongemoeid en de pull request wordt een concept, waar GitHub dat toestaat, met "niet mergen" in de titel. Zet de versie op een aparte tak gelijk aan de tag. Sluit de pull request daarna en verwijder de tak en de tag.

### Token

`GITHUB_TOKEN` werkt alleen in de eigen repo. Voor de pull request in een andere repo is daarom het secret `SITES_PR_TOKEN` nodig: een fine-grained token, alleen voor de sites uit de lijst, met Contents en Pull requests op lezen en schrijven.

Op `main` van `financieel-onafhankelijk` kan dit token niet rechtstreeks pushen: de ruleset eist een pull request met groene controle, zonder uitzonderingen. Mergen kan het token technisch wel. Niets in deze repo doet dat.

Het token staat alleen in de secrets van deze repo. Vernieuwen of instellen:

```bash
gh secret set SITES_PR_TOKEN -R hendrik-titolab/rekenkern
```

Verlopen? Dan faalt de run op het ophalen van de site en krijg je de gewone mail van GitHub. Na het vernieuwen de mislukte run opnieuw starten.

### Site toevoegen

1. De site heeft een Git-repo op GitHub, met `rekenkern` als `file:vendor/...` in `package.json`.
2. Geef het token toegang tot die repo.
3. Voeg de repo en de basisbranch toe aan `matrix.site`.

### Akkordvermogen

Staat in de lijst als tweede ontvanger, repo `hendrik-titolab/akkordvermogen`, branch `main`. Vercel zet `main` live. Er draait nog geen controle, dus een pull request laat daar geen groene controle zien, wel een testversie van Vercel.

Op een gratis GitHub-account kent een privé-repo geen rulesets, geen branchbescherming en geen concept-pull requests. Het token kan hier dus wel rechtstreeks naar `main` pushen, en daarmee live. De workflow doet dat niet: hij pusht alleen naar een eigen tak `rekenkern/v...`. Een proef wordt hier een gewone pull request met "niet mergen" in de titel.

## Status

Privé-repo: [hendrik-titolab/rekenkern](https://github.com/hendrik-titolab/rekenkern). `financieel-onafhankelijk` (lokaal `financiele-planning`) en `akkordvermogen` gebruiken het pakket uit hun map `vendor`.
