# Rekenkern

De berekeningen achter de rekentools, los van elke website. Afgesplitst uit `financiele-planning` op 3 november 2026 (commit 9a0a15b). Geen schermen, geen PDF- of Excel-export, geen browsercode.

## Wat erin zit

| Onderdeel | Bestand |
|---|---|
| Fiscale cijfers, gegenereerd | `src/config/fiscaleParameters.ts` |
| Risicoprofielen, gegenereerd | `src/config/risicoprofielen.ts` |
| Bruto-netto en box 1 | `src/utils/brutoNetto.ts` |
| Box 3 | `src/utils/box3.ts` |
| Jaarruimte | `src/utils/jaarruimte.ts` |
| Rente op rente, maandelijks beleggen | `src/utils/renteOpRente.ts` |
| Inflatie | `src/utils/inflatie.ts` |
| Planner en Monte Carlo | `src/utils/pensionCalc.ts`, `src/utils/monteCarlo.ts` |

## Controleren

```bash
npm test
```

```bash
npx tsc --noEmit
```

`src/utils/__tests__/narekenen.onafhankelijk.test.ts` vergelijkt de kern met `narekenen/waarden.py`. Dat script deelt geen code met de kern. Draai het opnieuw als de cijfers wijzigen, want de cijfers staan er apart in:

```bash
python narekenen/waarden.py
```

De controle op GitHub draait op Node 24, de versie waarop Vercel beide sites bouwt. Een Node-wissel mag een uitkomst niet stilzwijgend veranderen. Verhoog je de major, doe dat dan overal tegelijk: hier in `controle.yml` en `uitrol.yml`, en in beide sites in `controle.yml` en `engines.node` in `package.json`.

## Bijwerken

1. Fiscale cijfers wijzigen in `Documents\Fiscale bron\fiscale-cijfers.json`. Draai daar `node genereer.mjs`; die schrijft de twee gegenereerde bestanden in deze map.
2. Bij elke wijziging die een uitkomst verandert: `MODEL_VERSIE` ophogen in `src/config/modelVersie.ts`, met uitleg, en `version` in `package.json` gelijk houden. CI controleert dit voor elk bestand in `src/utils` en `src/config`. Raakt een wijziging daar aantoonbaar geen uitkomst (alleen commentaar), zet dan in een commit de regel `Modelversie-ongewijzigd: <reden>`.
3. Via een pull request naar `main`. Daar draait de controle.
4. Na de merge zet de workflow `Versie` (`.github/workflows/versie.yml`) zelf de tag `v<version>`, als de controle op `main` groen is en die tag nog niet bestaat. Daarna start de uitrol. Taggen met de hand hoeft dus niet meer, maar werkt nog wel.

Geen nieuw versienummer, dan geen tag en geen uitrol. Wil je een versie op `main` die nog niet naar de sites mag, verhoog `version` dan nog niet.

## Uitrol

Een nieuwe tag `v*` start de workflow `Uitrol naar sites` (`.github/workflows/uitrol.yml`). Zet `Versie` de tag, dan roept die de uitrol zelf aan: een tag die GitHub Actions zet, start uit veiligheid geen nieuwe workflow. Die draait de controle en zet daarna het pakket in een pull request bij elke site uit de lijst `matrix.site`. In die pull request draaien de controles van de site en maakt Vercel een testversie, voor zover de site die heeft.

**De workflow merget nooit.** Een merge naar `main` gaat direct live. Dat blijft een mensenbesluit, na het lezen van de pull request en het bekijken van de testversie.

Er komt geen pull request als:

- de controle faalt;
- `version` en `MODEL_VERSIE` niet gelijk zijn: dan wordt `Versie` rood en komt er geen tag;
- de tag niet gelijk is aan `version` in `package.json`, of aan `MODEL_VERSIE`;
- de tag niet op `main` staat;
- de site al op deze of een nieuwere versie staat.

Het pakket is een binair bestand, dus de diff zegt niets. Daarom staan in de tekst van de pull request de commits en de gewijzigde bestanden sinds de vorige tag. Alleen wat in het pakket zit telt mee: `src` zonder tests, zonder merge-commits. Een commit die alleen de uitrol, de README of de tests raakt, verandert bij de site niets en staat er niet in. `financieel-onafhankelijk` is een openbare repo, dus die tekst is openbaar, net als de broncode in het pakket.

Mergen gebeurt in de site. Daarna verwijdert GitHub de tak `rekenkern/v...` vanzelf: in alle drie de repo's staat "Automatically delete head branches" aan.

`scripts/wissel-pakket.mjs` past alleen de regels van rekenkern aan in `package.json` en `package-lock.json`, zodat er geen andere afhankelijkheden meeliften.

### Proef

Een tak `proef/...` met een versie als `2026.11.8-proef.1` test de route zonder risico. Push de tak: `Versie` zet dan de tag en de uitrol maakt bij de sites een concept met "niet mergen" in de titel. `MODEL_VERSIE` blijft ongemoeid. Sluit de pull requests daarna en verwijder de tak en de tag. Een tag `v...-proef.N` met de hand zetten werkt ook.

### Token

`GITHUB_TOKEN` werkt alleen in de eigen repo. Voor de pull request in een andere repo is daarom het secret `SITES_PR_TOKEN` nodig: een fine-grained token, alleen voor de sites uit de lijst, met Contents en Pull requests op lezen en schrijven.

Op `main` van `financieel-onafhankelijk` kan dit token niet rechtstreeks pushen: de ruleset eist een pull request met groene controle, zonder uitzonderingen. Mergen kan het token technisch wel. Niets in deze repo doet dat.

Het token staat alleen in de secrets van deze repo. Vernieuwen of instellen:

```bash
gh secret set SITES_PR_TOKEN -R hendrik-titolab/rekenkern
```

De workflow `Tokencheck` (`.github/workflows/tokencheck.yml`) kijkt elke maandag wanneer het token verloopt. Binnen 30 dagen, ongeldig of weg: dan opent hij een issue "SITES_PR_TOKEN vernieuwen" in deze repo, met de stappen. Daar krijg je een mail van. Een agendaherinnering is dus niet nodig.

Toch verlopen? Dan faalt de uitrol op het ophalen van de site. Na het vernieuwen de mislukte run opnieuw starten.

### Site toevoegen

1. De site heeft een Git-repo op GitHub, met `rekenkern` als `file:vendor/...` in `package.json`.
2. Geef het token toegang tot die repo.
3. Voeg de repo en de basisbranch toe aan `matrix.site`.

### Akkordvermogen

Staat in de lijst als tweede ontvanger, repo `hendrik-titolab/akkordvermogen`, branch `main`. Vercel zet `main` live. Sinds 25 november 2026 draait daar een eigen controle: tests, SEO-check op de draaiende build, build en typen.

Op een gratis GitHub-account kent een privé-repo geen rulesets en geen branchbescherming. Die controle waarschuwt dus alleen en houdt een merge niet tegen. Merge niet bij rood. Om dezelfde reden kan het token hier wel rechtstreeks naar `main` pushen, en daarmee live. De workflow doet dat niet: hij pusht alleen naar een eigen tak `rekenkern/v...`.

**Open:** GitHub Pro voor Akkord, zodat `main` daar dezelfde ruleset krijgt als bij de FO-site. Besluit Hendrik, uiterlijk vóór `site.publiek` aan gaat.

## Status

Privé-repo: [hendrik-titolab/rekenkern](https://github.com/hendrik-titolab/rekenkern). Stand 25 november 2026:

| | FO-site | Akkord |
|---|---|---|
| Repo | `financieel-onafhankelijk` (openbaar) | `akkordvermogen` (privé) |
| Lokaal | `C:\Users\schak\financiele-planning` | `C:\Users\schak\akkordvermogen` |
| Live vanaf | `main` (tot 25 november heette die `astro-migratie`) | `main` |
| Rekenkern | 2026.11.6 | 2026.11.6 |
| Node, Vercel en controle | 24 | 24 |
| Controle verplicht vóór merge | ja, ruleset op `main` | nee, waarschuwt alleen |
| Modelversie zichtbaar | bij box 3, jaarruimte en de planner; in de Excel-export | bij alle zeven tools; in de PDF- en Excel-export van de planner |

Welke versie een site nu gebruikt, staat in zijn `package.json` bij `rekenkern`. Deze tabel is een momentopname.
