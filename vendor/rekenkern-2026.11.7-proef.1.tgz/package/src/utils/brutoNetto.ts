import {
  BOX1_PRE_AOW,
  HEFFINGSKORTING_PRE_AOW,
  FISCAAL,
  type FiscaleFase,
} from '../config/fiscaleParameters'
import { PARAMETER_JAAR } from '../config/modelVersie'

// Rekenlogica van de bruto-nettotool. Stond tot augustus 2026 in
// src/components/BrutoNetto/index.tsx en was daardoor niet te testen zonder de
// React-component te renderen (bevinding A21). De verhuizing is letterlijk: geen
// enkele formule is aangepast.
//
// Let op bij E4: dit rekent uitsluitend met de tarieven en kortingen van vóór de
// AOW-leeftijd. Er is nog geen post-AOW-variant, terwijl de cijfers daarvoor
// inmiddels wel in FISCALE-BRONNEN.md staan.

// ── Fiscale parameters 2026 ───────────────────────────────────────────────────
// Alle getallen komen uit de centrale config (fiscaleParameters.ts), zodat de
// kwartaalcheck ze meeneemt. Hier alleen omgezet naar de vorm die de tool gebruikt.
export const P = {
  // De tool zet dit jaartal letterlijk op het scherm, boven de titel en boven het
  // paneel met de gebruikte cijfers. Het stond hier als los getal 2026 naast de
  // schijven eronder, die wel uit de config komen: bij een jaarwisseling zou het
  // label dus op 2026 blijven staan terwijl er met nieuwe cijfers gerekend wordt.
  // Stil verkeerd, en in Wft-gebied is een verkeerd jaartal boven een berekening
  // geen schoonheidsfout (WP9).
  jaar: PARAMETER_JAAR,
  schijven: [
    { tot: BOX1_PRE_AOW.schijf1Grens, tarief: BOX1_PRE_AOW.schijf1Tarief },
    { tot: BOX1_PRE_AOW.schijf2Grens, tarief: BOX1_PRE_AOW.schijf2Tarief },
    { tot: Infinity, tarief: BOX1_PRE_AOW.schijf3Tarief },
  ],
  ahk: HEFFINGSKORTING_PRE_AOW.algemeneHeffingskorting,
  ak: HEFFINGSKORTING_PRE_AOW.arbeidskorting,
} as const

// ── Types ─────────────────────────────────────────────────────────────────────

export interface SchijfDetail {
  van: number
  tot: number
  tarief: number
  grondslag: number
  bedrag: number
}

export interface BerekeningResultaat {
  brutoJaar: number
  belastingBruto: number
  schijfDetail: SchijfDetail[]
  ahk: number
  ak: number
  /** Alleen na de AOW-leeftijd, anders 0. */
  ouderenkorting: number
  /** Alleen na de AOW-leeftijd én alleenstaand, anders 0. */
  alleenstaandeouderenkorting: number
  kortingenBenut: number
  teBetalen: number
  nettoJaar: number
  druk: number
}

// ── Berekeningen ──────────────────────────────────────────────────────────────

export function belastingSchijven(
  bruto: number,
  schijven: readonly { tot: number; tarief: number }[] = P.schijven,
): { totaal: number; detail: SchijfDetail[] } {
  let rest = bruto, vorigeGrens = 0, totaal = 0
  const detail: SchijfDetail[] = []
  for (const s of schijven) {
    const inSchijf = Math.max(0, Math.min(bruto, s.tot) - vorigeGrens)
    const bedrag = inSchijf * s.tarief
    if (inSchijf > 0) detail.push({ van: vorigeGrens, tot: Math.min(bruto, s.tot), tarief: s.tarief, grondslag: inSchijf, bedrag })
    totaal += bedrag
    vorigeGrens = s.tot
    rest -= inSchijf
    if (rest <= 0) break
  }
  return { totaal, detail }
}

export function algemeneHeffingskorting(inkomen: number): number {
  const { max, afbouwVanaf, afbouwPct } = P.ahk
  if (inkomen <= afbouwVanaf) return max
  return Math.max(0, max - afbouwPct * (inkomen - afbouwVanaf))
}

interface ArbeidskortingParams {
  knik1: number; pct1: number
  knik2: number; pct2: number
  knik3: number; pct3: number
  afbouwVanaf: number; afbouwPct: number
  max: number
}

/** Trapsgewijze opbouw, daarna lineaire afbouw. Werkt voor beide leeftijdsvarianten. */
export function arbeidskortingVoor(inkomen: number, a: ArbeidskortingParams): number {
  let k: number
  if (inkomen <= a.knik1) k = a.pct1 * inkomen
  else if (inkomen <= a.knik2) k = a.pct1 * a.knik1 + a.pct2 * (inkomen - a.knik1)
  else if (inkomen <= a.knik3) k = a.pct1 * a.knik1 + a.pct2 * (a.knik2 - a.knik1) + a.pct3 * (inkomen - a.knik2)
  else k = a.max - a.afbouwPct * (inkomen - a.afbouwVanaf)
  return Math.max(0, Math.min(a.max, k))
}

export function arbeidskorting(inkomen: number): number {
  return arbeidskortingVoor(inkomen, P.ak)
}

// ── Fase-bewuste variant (E4) ─────────────────────────────────────────────────
//
// belastingBox1() is sinds E4 (13 augustus 2026) de gedeelde belastingmotor: de
// FO-planner rekent ermee op het totale box 1-inkomen, voor en na de AOW-leeftijd.
// Daarvoor paste pensionCalc.ts alleen schijftarieven toe, zonder heffingskortingen,
// en gaf hij voor hetzelfde bruto een ander netto dan de bruto-nettotool.
//
// TWEE VALKUILEN VOOR WIE DIT ERGENS ANDERS AANSLUIT:
//
// 1. AOW_NETTO_MAAND is al een NETTO bedrag inclusief loonheffingskorting. Wie
//    dat bedrag optelt bij een bruto pensioen en daarna deze functie loslaat op
//    het totaal, telt de heffingskorting dubbel. De AOW hoort er als netto
//    bedrag naast te blijven staan, of bruto gemaakt te worden vóór de optelling.
//
// 2. De kortingen zijn inkomensafhankelijk over het TOTALE box 1-inkomen. Ze per
//    inkomensbron apart berekenen geeft een te hoge korting. AOW,
//    werkgeverspensioen en lijfrente moeten dus eerst opgeteld worden.
//
// Het marginale tarief loopt na de AOW-leeftijd hoger op dan het schijftarief
// suggereert. In 2026 stapelen tussen € 46.002 en € 59.782 het schijftarief van
// 37,56%, 15% afbouw ouderenkorting en 3,195% afbouw algemene heffingskorting tot
// 55,8% (HEFFINGSKORTING_POST_AOW en BOX1_POST_AOW).

export interface BelastingOpties {
  /** Bepaalt de schijftarieven én welke kortingen gelden. */
  pastAow: boolean
  /**
   * Deel van het inkomen dat arbeidsinkomen is, voor de arbeidskorting.
   * Standaard het hele bedrag, wat klopt voor een werknemer. Voor een
   * gepensioneerde hoort hier 0: een werkgeverspensioen is geen arbeidsinkomen.
   */
  arbeidsinkomen?: number
  /** Geeft recht op de alleenstaandeouderenkorting. Alleen na de AOW-leeftijd. */
  alleenstaand?: boolean
  /**
   * Het jaar waarvan de schijven en heffingskortingen gelden. Standaard het
   * parameterjaar van de site.
   *
   * Dit is niet hetzelfde als het kalenderjaar waarin gerekend wordt. De
   * jaarruimtetool schat het belastingvoordeel van een aftrek in het aftrekjaar
   * dat de gebruiker koos, en dat kan een ander jaar zijn dan vandaag.
   */
  belastingjaar?: number
}

/**
 * De tarieven en kortingen van één belastingjaar, vóór of ná de AOW-leeftijd.
 *
 * Gooit liever een leesbare fout dan stilzwijgend terug te vallen op een ander
 * jaar. Een berekening die met de verkeerde schijven is gedaan en er verder
 * normaal uitziet, is in Wft-gebied gevaarlijker dan een berekening die weigert:
 * de gebruiker ziet geen enkel signaal dat het bedrag niet klopt. Dezelfde keuze
 * als getParams() in jaarruimte.ts al maakt (WP9, fase 2).
 */
export function fiscaleFaseVoor(pastAow: boolean, belastingjaar: number = PARAMETER_JAAR): FiscaleFase {
  const jaar = FISCAAL[belastingjaar]
  if (!jaar) {
    throw new Error(
      `Geen fiscale cijfers bekend voor belastingjaar ${belastingjaar}. ` +
      `Bekend: ${Object.keys(FISCAAL).join(', ')}.`)
  }
  const fase = pastAow ? jaar.postAow : jaar.preAow
  if (!fase) {
    throw new Error(
      `Voor ${belastingjaar} zijn alleen de cijfers van vóór de AOW-leeftijd bekend, ` +
      `en er is om de cijfers van erna gevraagd. Zie _dekking in fiscale-cijfers.json.`)
  }
  return fase
}

// tot is null bij de laatste schijf, die geen bovengrens heeft. belastingSchijven()
// rekent met Infinity, dus dat wordt hier vertaald.
function schijvenVoor(pastAow: boolean, belastingjaar?: number) {
  return fiscaleFaseVoor(pastAow, belastingjaar).schijven
    .map(s => ({ tot: s.tot ?? Infinity, tarief: s.tarief }))
}

/** Lineair afgebouwde korting: onder de grens het maximum, daarboven aflopend tot nul. */
function afgebouwdeKorting(
  inkomen: number,
  k: { max: number; afbouwVanaf: number; afbouwPct: number; nihilBij: number },
): number {
  if (inkomen <= k.afbouwVanaf) return k.max
  // Vanaf nihilBij is de korting nul, zoals de wet het bedrag noemt. Het afbouwpercentage is
  // afgerond, dus de formule raakt nul niet precies daar: na de AOW-leeftijd bleef er tot
  // € 1,37 staan (review deel 1, B4).
  if (inkomen >= k.nihilBij) return 0
  return Math.max(0, k.max - k.afbouwPct * (inkomen - k.afbouwVanaf))
}

export function belastingBox1(brutoJaar: number, opties: BelastingOpties): BerekeningResultaat {
  const { pastAow, alleenstaand = false, belastingjaar = PARAMETER_JAAR } = opties
  const arbeidsinkomen = opties.arbeidsinkomen ?? brutoJaar

  const fase = fiscaleFaseVoor(pastAow, belastingjaar)
  const { totaal: belasting, detail } = belastingSchijven(brutoJaar, schijvenVoor(pastAow, belastingjaar))

  const ahk = afgebouwdeKorting(brutoJaar, fase.algemeneHeffingskorting)
  const ak = arbeidskortingVoor(arbeidsinkomen, fase.arbeidskorting)
  // De ouderenkortingen bestaan alleen ná de AOW-leeftijd, en dus alleen op een
  // fase die ze meebrengt. fiscaleFaseVoor() heeft hierboven al geweigerd als er
  // om een postAow-fase is gevraagd die er niet is.
  const ouderenkorting = fase.ouderenkorting
    ? afgebouwdeKorting(brutoJaar, fase.ouderenkorting)
    : 0
  const alleenstaandeouderenkorting = alleenstaand
    ? fase.alleenstaandeouderenkorting ?? 0
    : 0

  const kortingen = Math.min(
    belasting,
    ahk + ak + ouderenkorting + alleenstaandeouderenkorting,
  )
  const teBetalen = belasting - kortingen

  return {
    brutoJaar,
    belastingBruto: belasting,
    schijfDetail: detail,
    ahk,
    ak,
    ouderenkorting,
    alleenstaandeouderenkorting,
    kortingenBenut: kortingen,
    teBetalen,
    nettoJaar: brutoJaar - teBetalen,
    druk: brutoJaar > 0 ? teBetalen / brutoJaar : 0,
  }
}

/** Bruto naar netto voor een werknemer onder de AOW-leeftijd. Wat de bruto-nettotool gebruikt. */
export function brutoNaarNetto(brutoJaar: number, belastingjaar?: number): BerekeningResultaat {
  return belastingBox1(brutoJaar, { pastAow: false, belastingjaar })
}

export function nettoNaarBruto(nettoJaar: number, belastingjaar?: number): BerekeningResultaat {
  let lo = nettoJaar, hi = nettoJaar * 2.5 + 50_000
  for (let i = 0; i < 80; i++) {
    const mid = (lo + hi) / 2
    if (brutoNaarNetto(mid, belastingjaar).nettoJaar < nettoJaar) lo = mid
    else hi = mid
  }
  return brutoNaarNetto((lo + hi) / 2, belastingjaar)
}
