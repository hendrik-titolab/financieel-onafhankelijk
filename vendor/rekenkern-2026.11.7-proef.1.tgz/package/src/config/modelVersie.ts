/**
 * Versie van de rekenmodellen en de peildatum van de fiscale parameters.
 *
 * Een uitgebracht rapport moet later terug te vinden zijn: welke formules en welke
 * belastingcijfers stonden erachter. Zonder dat is een advies uit maart niet te
 * onderscheiden van een advies uit september, terwijl de uitkomsten kunnen
 * verschillen. Dat is ook het antwoord op de offline-app: een gecachete versie
 * draagt zijn eigen versienummer mee (audit 7 september 2026, bevindingen 6 en 26).
 *
 * Ophogen bij elke wijziging die een uitkomst verandert. Niet bij tekst of opmaak.
 */
// 2026.09.2: box 3 per jaar in de planner, partner apart belast, reële volatiliteit (8 en 9 september 2026).
// 2026.09.3: overbruggingsToeslag telt het box 3-verschil niet meer mee als er geen
// echte overbruggingsperiode is (14 september 2026).
// 2026.09.4: de jaarruimtetool schat het belastingvoordeel met de schijven en
// heffingskortingen van het aftrekjaar zelf, in plaats van altijd met die van het
// parameterjaar (WP9, 16 september 2026). Raakt alleen aftrekjaren ongelijk aan
// PARAMETER_JAAR; de jaarruimte zelf verandert nergens.
// 2026.09.5: review 22 september 2026. Liquiditeitstoets in de opbouwfase, sluitende
// opbouw van het doelbedrag (overbrugging, later geld, box 3), indexatiekeuze per
// uitkering, Monte Carlo met een startwaarde uit de invoer, slechtweerwaarde
// (5e percentiel) op de pensioendatum.
// 2026.09.6: risicoprofielen afgeleid uit gepubliceerde bronnen (aandelen 8,0%,
// obligaties 3,5%) en scenario-schakelaars (28 september 2026).
// 2026.09.7: fiscale cijfers nagelopen tegen de primaire bronnen (28 september 2026).
// AOW-bruto, vakantiegeld en Zvw per 1 juli 2026 rechtstreeks van de SVB (de
// vakantiegeldfactor daalt van 1,064086 naar 1,063038 alleenstaand), en de afbouw
// van de arbeidskorting begint bij 45.592 in plaats van 45.593 (maximaal 7 cent).
// Eenmalige bedragen zijn nominaal: het bedrag in het jaar zelf, teruggerekend naar
// koopkracht van nu (besluit Hendrik, zelfde dag).
// 2026.09.8: jaarruimte. Het belastingvoordeel rekent met de tarieven na de
// AOW-leeftijd als de geboortedatum dat aangeeft (in het AOW-jaar gewogen per maand),
// een leeftijdswaarschuwing volgens art. 3.127 lid 1, en voor 2021 en 2022 gaat de
// toevoeging aan de oudedagsreserve van de jaarruimte af (28 september 2026).
// 2026.09.9: jaarruimte. De wizard voor eerdere jaren trekt de oudedagsreserve af
// (tot en met 2022), en het belastingvoordeel kan rekenen met een apart opgegeven
// inkomen en arbeidsinkomen in het aftrekjaar (28 september 2026).
// 2026.11.1: jaarruimte. Een geboortedatum wordt als lokale kalenderdatum gelezen en
// niet als middernacht UTC. Ten westen van Greenwich viel de AOW-datum een dag te
// vroeg, en voor wie op de 1e geboren is in de maand ervoor: dan verschoof ook de
// AOW-fase en daarmee het belastingvoordeel. In Nederland verandert er niets
// (3 november 2026).
// 2026.11.2: de benodigde maandinleg heeft geen vaste bovengrens van € 200.000 meer.
// Raakt alleen uitkomsten boven dat bedrag (3 november 2026).
// 2026.11.3: box 3. Een direct opgegeven werkelijk rendement dat geen getal is (NaN,
// Infinity) telt als niet ingevuld: het forfait geldt. Was: € 0 belasting (review deel 1,
// B1, 10 november 2026).
// 2026.11.4: de benodigde maandinleg heeft ook geen vaste ondergrens van min € 50.000 meer.
// Raakt alleen een overschot zo groot dat de inleg daaronder ligt; het rapport toont hem als
// € 0 (review deel 1, B2, 10 november 2026).
// 2026.11.5: algemene heffingskorting en ouderenkorting zijn nul vanaf nihilBij. Door het
// afgeronde afbouwpercentage bleef er tussen nihilBij en het nulpunt van de formule tot
// € 1,37 staan (2025, na AOW). Raakt alleen inkomens binnen een paar tientjes boven nihilBij
// (review deel 1, B4, 10 november 2026).
// 2026.11.6: PensionResult geeft de eenmalige bedragen terug die in het verleden liggen en
// daarom niet meetellen (overgeslagenEenmaligeBedragen). De bedragen zelf veranderen niet;
// de site kan nu melden wat er wegvalt (review deel 1, B5, 10 november 2026).
export const MODEL_VERSIE = '2026.11.6'

/** Belastingjaar waarop fiscaleParameters.ts is gebaseerd. */
export const PARAMETER_JAAR = 2026

/** Datum waarop die parameters voor het laatst zijn nagelopen. */
export const PARAMETER_PEILDATUM = '2026-09-28'

/** Korte weergave voor scherm en rapport, bijv. "model 2026.09.1 · cijfers 2026". */
export function modelStempel(): string {
  return `model ${MODEL_VERSIE} · fiscale cijfers ${PARAMETER_JAAR}`
}
