import type { PensionInputs, MonteCarloResult, PercentilePoint } from '../types'
import { brutoMaandNaarNettoMaand, getMonthlyWithdrawal, controleerLeeftijden, huishoudOp, eenmaligInKoopkracht } from './pensionCalc'
import type { HuishoudOpParams } from './pensionCalc'
import { nettoNominaalRendement, box3HeffingPerJaar } from './box3'
import { makeRng } from './rng'

export const N_SIMULATIONS = 2000

/**
 * Een startwaarde voor de toevalsgenerator, afgeleid uit de invoer (FNV-1a, 32 bit).
 *
 * Tot 22 september 2026 trok de simulatie met Math.random. Tien keer rekenen op
 * precies dezelfde invoer gaf dan een slagingskans tussen 46,8% en 50,1%, terwijl
 * het scherm één decimaal toonde (review 22 september 2026, bevinding 7). Nu geeft
 * dezelfde invoer altijd hetzelfde getal. Dat maakt de onzekerheid van 2.000
 * scenario's niet kleiner, maar een verschil op het scherm komt voortaan alleen nog
 * van een andere invoer.
 */
export function startwaardeVoorInvoer(inputs: PensionInputs, currentYear: number): number {
  const tekst = JSON.stringify(inputs) + '|' + currentYear
  let h = 0x811c9dc5
  for (let i = 0; i < tekst.length; i++) {
    h ^= tekst.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return h >>> 0
}

function sampleNormal(mean: number, std: number, rng: () => number): number {
  // log(0) is min oneindig. De generator kan precies 0 teruggeven; dat ene geval
  // vervangen door het kleinste positieve getal verandert geen andere trekking.
  const u1 = rng() || Number.MIN_VALUE
  const u2 = rng()
  return mean + std * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2)
}

// De rendementen in risicoprofielen.ts zijn verwachte MEETKUNDIGE (samengestelde)
// jaarrendementen, niet rekenkundige gemiddelden (besluit 12 augustus 2026).
// Trek daarom lognormaal: de mediaan van het samengestelde pad is dan exact
// (1+g)^n, in plaats van er structureel onder te liggen (E8).
// Twee bijvangsten: een trekking kan niet meer onder −100% rendement uitkomen (het
// mechanisme achter E6), en een pad kan het vermogen niet negatief maken door
// rendement alleen.
function sampleAnnualReturn(geoMeanPct: number, volPct: number, rng: () => number): number {
  const g = geoMeanPct / 100
  const s = volPct / 100  // volatiliteit staat in hele procentpunten
  // Randgeval: een reëel rendement van −100% of lager (absurde inflatie-invoer)
  // laat zich niet lognormaal modelleren. Val dan terug op een vast verlies.
  if (g <= -1) return -1
  const mu = Math.log(1 + g)
  const sigma = Math.sqrt(Math.log(1 + (s * s) / ((1 + g) * (1 + g))))
  return Math.exp(sampleNormal(mu, sigma, rng)) - 1
}

function percentile(arr: number[], p: number): number {
  const sorted = [...arr].sort((a, b) => a - b)
  const idx = (p / 100) * (sorted.length - 1)
  const lo = Math.floor(idx)
  const hi = Math.ceil(idx)
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo)
}

function realReturn(nominal: number, inflation: number): number {
  return ((1 + nominal / 100) / (1 + inflation / 100) - 1) * 100
}

/**
 * De standaardafwijking die bij een REËEL rendement hoort, afgeleid uit de
 * nominale standaardafwijking die de gebruiker invult.
 *
 * Tot september 2026 ging er een reëel verwacht rendement de trekking in met een
 * nominale standaardafwijking ernaast. Die twee horen niet bij elkaar. Omdat de
 * inflatie in dit model een vast getal is, is de omrekening exact: elk nominaal
 * rendement wordt gedeeld door (1 + inflatie), en dus schaalt de spreiding mee
 * met diezelfde deling.
 *
 *   σ_reëel = σ_nominaal / (1 + inflatie)
 *
 * Bij 12% en 3% inflatie geeft dat 11,65%. De log-sigma die sampleAnnualReturn()
 * daaruit afleidt gaat van 0,11621 naar 0,11285, dus 2,9% lager.
 *
 * WAT DIT NIET OPLOST, en dat weegt zwaarder dan de correctie zelf. Dit model
 * behandelt inflatie als zeker: één vast percentage voor de hele looptijd. In
 * werkelijkheid varieert inflatie, en dat maakt een reëel rendement onzekerder
 * dan hier wordt getoond. De te hoge volatiliteit van hiervoor compenseerde dat
 * per ongeluk een beetje. Deze correctie maakt de berekening intern kloppend, ze
 * maakt het risicobeeld niet automatisch realistischer. Lees de bandbreedte in de
 * grafiek dus niet als een volledige weergave van het risico.
 *
 * Stochastische inflatie, en de correlatie tussen inflatie en rendement, staan
 * als openstaand punt in CLAUDE.md.
 */
export function reeleVolatiliteit(volatiliteitNominaal: number, inflatie: number): number {
  return volatiliteitNominaal / (1 + inflatie / 100)
}

export function runMonteCarlo(inputs: PensionInputs, opts?: { rng?: () => number; currentYear?: number }): MonteCarloResult {
  const currentYear = opts?.currentYear ?? new Date().getFullYear()
  const rng = opts?.rng ?? makeRng(startwaardeVoorInvoer(inputs, currentYear))
  const {
    currentAge, retirementAge: retirementAgeInput, lifeExpectancy,
    currentCapital, monthlyContribution, contributionFrequency,
    returnBeforeRetirement, returnAfterRetirement, inflation,
    kostenPct = 0, vermogensbelastingPct = 0, vermogensbelastingHandmatig = true,
    desiredRetirementIncome, desiredRetirementIncomeType,
    aowMaandBedragNetto, aowStartAge, woonsituatie = 'alleenstaand',
    employerPension, employerPensionStartAge,
    lijfrenteUitkering, lijfrenteStartAge,
    lijfrenteSoort = 'levenslang', lijfrenteEindLeeftijd = Infinity,
    employerPensionIndexatie = 'meestijgend', lijfrenteIndexatie = 'meestijgend',
    aowVakantiegeld = false,
    partner,
    lifeEvents = [],
    volatilityPre, volatilityPost,
  } = inputs

  // Dezelfde lezing van de leeftijden als calculatePension(). Die twee liepen
  // uiteen bij een combinatie die zichzelf tegenspreekt: bij huidige leeftijd 70,
  // stoppen op 60 en eindleeftijd 65 liep de deterministische kern vanaf leeftijd
  // 60 door terwijl deze lus nul jaren doorliep en 100% slagingskans meldde
  // (audit 7 september 2026, bevinding 3).
  const retirementAge = controleerLeeftijden(
    currentAge, retirementAgeInput, lifeExpectancy
  ).effectiveRetirementAge

  const aowMonthlyNetto = aowMaandBedragNetto
  const lijfrenteEinde = lijfrenteSoort === 'tijdelijk' ? lijfrenteEindLeeftijd : Infinity

  // Eén kaart over de hele looptijd, opbouw- én uitkeringsfase. Was tot augustus
  // 2026 gefilterd op year < retirementYear, waardoor een eenmalig bedrag ná de
  // pensioendatum de slagingskans en de bandbreedte niet raakte terwijl het de
  // deterministische lijn wél verschoof (E7).
  const eventMap = new Map<number, number>()
  for (const e of lifeEvents) {
    if (e.year >= currentYear && e.amount !== 0) {
      // Nominaal ingevuld, dus terug naar koopkracht van vandaag (zie pensionCalc.ts).
      const reeel = eenmaligInKoopkracht(e.amount, e.year, currentYear, inflation)
      eventMap.set(e.year, (eventMap.get(e.year) ?? 0) + reeel)
    }
  }
  // Zelfde conversie als calculatePension(): via de volledige belastingmotor, met
  // het regime dat op de pensioendatum geldt. Stond hier los van de deterministische
  // kern met een eigen maandbedrag-tegen-jaarschijven-conversie, waardoor beide
  // kernen van een ander netto doelinkomen uitgingen.
  const desiredNetto = desiredRetirementIncomeType === 'bruto'
    ? brutoMaandNaarNettoMaand(
        desiredRetirementIncome,
        retirementAge >= aowStartAge,
        woonsituatie === 'alleenstaand'
      )
    : desiredRetirementIncome

  // Zelfde twee routes voor box 3 als in pensionCalc.ts, zie de uitleg daar. Of
  // het percentage van het rendement af gaat, of de heffing gaat per jaar in
  // euro's van het saldo af. Nooit allebei.
  const belastingViaPercentage = vermogensbelastingHandmatig ? vermogensbelastingPct : 0
  const heffing = vermogensbelastingHandmatig
    ? () => 0
    : (vermogenBeginJaar: number) => box3HeffingPerJaar(vermogenBeginJaar, woonsituatie)

  const realPre = realReturn(
    nettoNominaalRendement(returnBeforeRetirement, kostenPct, belastingViaPercentage), inflation)
  const realPost = realReturn(
    nettoNominaalRendement(returnAfterRetirement, kostenPct, belastingViaPercentage), inflation)

  const volPre = reeleVolatiliteit(volatilityPre, inflation)
  const volPost = reeleVolatiliteit(volatilityPost, inflation)

  // Zelfde gedeelde huishoudOp() als pensionCalc.ts, zodat beide kernen hetzelfde
  // huishouden doorrekenen (was tot 14 september 2026 een eigen, bijna-identieke
  // kopie hier).
  const partnerActief = Boolean(partner?.actief)
  const huishoudOpParams: HuishoudOpParams = {
    woonsituatie, aowVakantiegeld, currentAge,
    aowMonthlyNetto, aowStartAge,
    employerPension, employerPensionStartAge,
    lijfrenteUitkering, lijfrenteStartAge, lijfrenteEinde,
    partnerActief, partner,
    inflation, employerPensionIndexatie, lijfrenteIndexatie,
  }
  const monthlyPMT = contributionFrequency === 'jaarlijks'
    ? monthlyContribution / 12
    : monthlyContribution

  const totalYears = Math.max(0, lifeExpectancy - currentAge)

  const capitalByAge: number[][] = Array.from(
    { length: totalYears + 1 },
    () => new Array(N_SIMULATIONS).fill(0)
  )

  let successCount = 0
  let successCount75 = 0

  for (let sim = 0; sim < N_SIMULATIONS; sim++) {
    let capital = currentCapital
    // Parallel tracker: same economic scenario, but client only needs 75% of income from capital.
    // Using the same random returns ensures a fair like-for-like comparison.
    let capital75 = currentCapital
    // Een pad is pas geslaagd als het kapitaal onderweg nooit onder nul is gedoken.
    // Alleen naar de eindstand kijken telt een pad dat halverwege de uitkeringsfase
    // leegloopt ten onrechte mee zodra het daarna weer boven nul uitkomt (E6).
    let everNegative = false
    let everNegative75 = false

    for (let yr = 0; yr < totalYears; yr++) {
      const age = currentAge + yr
      const calYear = currentYear + yr
      // Eenmalig bedrag aan het begin van het jaar, dan rendement, dan de
      // onttrekking. Zelfde volgorde als pensionCalc.ts.
      const event = eventMap.get(calYear) ?? 0
      capitalByAge[yr][sim] = Math.max(0, capital)

      if (age < retirementAge) {
        const r = sampleAnnualReturn(realPre, volPre, rng)
        // Mid-year-conventie voor de jaarinleg, zelfde reden en zelfde
        // Math.sqrt(1+r) als in pensionCalc.ts's simulateAccumulation. r kan
        // hier niet onder -100% uitkomen (lognormale trekking, zie
        // sampleAnnualReturn), dus 1+r is altijd positief en de wortel is
        // altijd reëel.
        const groeifactorInleg = Math.sqrt(1 + r)
        // De heffing gaat over het saldo aan het begin van het jaar, zelfde
        // peildatumconventie als in pensionCalc.ts. Beide paden krijgen hun eigen
        // heffing, want ze hebben een verschillend vermogen: het 75%-pad houdt
        // meer over en betaalt dus meer.
        const beginSaldo   = capital   + event
        const beginSaldo75 = capital75 + event
        capital   = beginSaldo   * (1 + r) + monthlyPMT * 12 * groeifactorInleg - heffing(beginSaldo)
        capital75 = beginSaldo75 * (1 + r) + monthlyPMT * 12 * groeifactorInleg - heffing(beginSaldo75)
      } else {
        const r = sampleAnnualReturn(realPost, volPost, rng)
        // Full income scenario
        const withdrawal = getMonthlyWithdrawal(huishoudOp(huishoudOpParams, age, desiredNetto)) * 12
        // 75% income scenario: client accepts 25% lower total income
        // getMonthlyWithdrawal handles phase-aware tax: fixed income (AOW + emp + lijfrente)
        // already covers part of the 75% threshold, so the capital withdrawal is reduced accordingly.
        const withdrawal75 = getMonthlyWithdrawal(huishoudOp(huishoudOpParams, age, desiredNetto * 0.75)) * 12
        // Mid-year-conventie voor de onttrekking, zelfde wortelfactor en zelfde
        // reden als bij de jaarinleg hierboven en als in pensionCalc.ts. Zonder
        // deze factor rekende de simulatie alsof het hele jaarbedrag pas op
        // 31 december werd opgenomen, terwijl de inleg wél maandelijks was.
        const groeifactorOpname = Math.sqrt(1 + r)
        const beginSaldo   = capital   + event
        const beginSaldo75 = capital75 + event
        capital   = beginSaldo   * (1 + r) - withdrawal   * groeifactorOpname - heffing(beginSaldo)
        capital75 = beginSaldo75 * (1 + r) - withdrawal75 * groeifactorOpname - heffing(beginSaldo75)
      }

      // Liquiditeitstoets voor élk jaar, ook in de opbouwfase. Stond tot september
      // 2026 binnen de uitkeringstak hierboven, waardoor een uitgave die de pot
      // vóór de pensioendatum onder nul duwde niet als mislukking telde: de pot
      // dook negatief, groeide daarna gewoon door en het pad heette geslaagd.
      // Het geval uit de audit van 7 september 2026: geen vermogen, nu € 10.000
      // uitgeven, volgend jaar € 20.000 ontvangen, geen rendement en geen
      // inkomensdoel gaf 100% succes, terwijl de eerste uitgave nergens
      // gefinancierd werd (bevinding 4).
      if (capital   < 0) everNegative   = true
      if (capital75 < 0) everNegative75 = true
    }
    capitalByAge[totalYears][sim] = Math.max(0, capital)
    if (!everNegative)   successCount++
    if (!everNegative75) successCount75++
  }

  const percentileData: PercentilePoint[] = []
  for (let yr = 0; yr <= totalYears; yr++) {
    const age = currentAge + yr
    percentileData.push({
      age,
      p10: Math.max(0, percentile(capitalByAge[yr], 10)),
      p25: Math.max(0, percentile(capitalByAge[yr], 25)),
      p50: Math.max(0, percentile(capitalByAge[yr], 50)),
      p75: Math.max(0, percentile(capitalByAge[yr], 75)),
      p90: Math.max(0, percentile(capitalByAge[yr], 90)),
    })
  }

  // Het vermogen op de pensioendatum in het slechtweerscenario: het 5e percentiel,
  // de maat die pensioenfondsen hanteren (art. 30b lid 5 Regeling Pensioenwet en
  // Wvb). Is iemand al met pensioen, dan is dat het vermogen van vandaag.
  const pensioenIndex = Math.min(totalYears, Math.max(0, retirementAge - currentAge))

  return {
    successRate: (successCount / N_SIMULATIONS) * 100,
    successRate75: (successCount75 / N_SIMULATIONS) * 100,
    percentileData,
    slechtWeerBijPensioen: Math.max(0, percentile(capitalByAge[pensioenIndex], 5)),
  }
}
