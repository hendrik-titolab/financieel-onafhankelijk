# Rekenkern

De berekeningen achter de rekentools, los van elke website. Afgesplitst uit `financiele-planning` op 3 november 2026 (commit 9a0a15b). Geen schermen, geen PDF- of Excel-export, geen browsercode.

## Wat erin zit

| Onderdeel | Bestand |
|---|---|
| Fiscale cijfers, gegenereerd | `src/config/fiscaleParameters.ts` |
| Risicoprofielen, gegenereerd | `src/config/risicoprofielen.ts` |
| Bruto-netto en box 1 | `src/utils/brutoNetto.ts` |
| Box 3 | `src/utils/box3.ts` |
| Jaarruimte | `src/utils/jaarruimte.ts` |
| Rente op rente, maandelijks beleggen | `src/utils/renteOpRente.ts` |
| Inflatie | `src/utils/inflatie.ts` |
| Planner en Monte Carlo | `src/utils/pensionCalc.ts`, `src/utils/monteCarlo.ts` |

## Controleren

```bash
npm test
```

```bash
npx tsc --noEmit
```

`src/utils/__tests__/narekenen.onafhankelijk.test.ts` vergelijkt de kern met `narekenen/waarden.py`. Dat script deelt geen code met de kern. Draai het opnieuw als de cijfers wijzigen, want de cijfers staan er apart in:

```bash
python narekenen/waarden.py
```

## Bijwerken

1. Fiscale cijfers wijzigen in `Documents\Fiscale bron\fiscale-cijfers.json`. Draai daar `node genereer.mjs`; die schrijft de twee gegenereerde bestanden in deze map.
2. Bij elke wijziging die een uitkomst verandert: `MODEL_VERSIE` ophogen in `src/config/modelVersie.ts`, met uitleg, en `version` in `package.json` gelijk houden. CI controleert dit voor elk bestand in `src/utils` en `src/config`. Raakt een wijziging daar aantoonbaar geen uitkomst (alleen commentaar), zet dan in een commit de regel `Modelversie-ongewijzigd: <reden>`.
3. Pakket maken en in de site zetten:

```bash
npm pack --pack-destination ../financiele-planning/vendor
```

```bash
npm install ./vendor/rekenkern-<versie>.tgz
```

Het pakket staat in de map `vendor` van de site, zodat die los van deze map bouwt. De FO-site (repo `financieel-onafhankelijk`, lokaal `../financiele-planning`) en `akkordvermogen` hebben elk een eigen `vendor`; zet een nieuw pakket in beide. Automatisch bijwerken via een versienummer is de volgende stap.

## Status

Privé-repo: [hendrik-titolab/rekenkern](https://github.com/hendrik-titolab/rekenkern). `financieel-onafhankelijk` (lokaal `financiele-planning`) en `akkordvermogen` gebruiken het pakket uit hun map `vendor`.
