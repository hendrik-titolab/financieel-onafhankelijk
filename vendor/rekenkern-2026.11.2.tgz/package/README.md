# Rekenkern

De berekeningen achter de rekentools, los van elke website. Afgesplitst uit `financiele-planning` op 3 november 2026 (commit 9a0a15b). Geen schermen, geen PDF- of Excel-export, geen browsercode.

## Wat erin zit

| Onderdeel | Bestand |
|---|---|
| Fiscale cijfers, gegenereerd | `src/config/fiscaleParameters.ts` |
| Risicoprofielen, gegenereerd | `src/config/risicoprofielen.ts` |
| Bruto-netto en box 1 | `src/utils/brutoNetto.ts` |
| Box 3 | `src/utils/box3.ts` |
| Jaarruimte | `src/utils/jaarruimte.ts` |
| Rente op rente, maandelijks beleggen | `src/utils/renteOpRente.ts` |
| Inflatie | `src/utils/inflatie.ts` |
| Planner en Monte Carlo | `src/utils/pensionCalc.ts`, `src/utils/monteCarlo.ts` |

## Controleren

```bash
npm test
```

```bash
npx tsc --noEmit
```

`src/utils/__tests__/narekenen.onafhankelijk.test.ts` vergelijkt de kern met `narekenen/waarden.py`. Dat script deelt geen code met de kern. Draai het opnieuw als de cijfers wijzigen, want de cijfers staan er apart in:

```bash
python narekenen/waarden.py
```

## Bijwerken

1. Fiscale cijfers wijzigen in `Documents\Fiscale bron\fiscale-cijfers.json`. De generator schrijft nu nog naar `financiele-planning`; kopieer de twee gegenereerde bestanden hierheen, of wijs de generator naar deze map.
2. Bij elke wijziging die een uitkomst verandert: `MODEL_VERSIE` ophogen in `src/config/modelVersie.ts`, met uitleg, en `version` in `package.json` gelijk houden.
3. Pakket maken en in de site zetten:

```bash
npm pack --pack-destination ../akkordvermogen/vendor
```

```bash
npm install ./vendor/rekenkern-2026.11.2.tgz
```

Het pakket staat in de map `vendor` van de site, zodat die los van deze map bouwt. Automatisch bijwerken via een versienummer is de volgende stap.

## Status

Privé-repo: [hendrik-titolab/rekenkern](https://github.com/hendrik-titolab/rekenkern). `financiele-planning` draait nog op zijn eigen kopie en wijkt op één punt af, zie `MODEL_VERSIE` 2026.11.2.
